# Information for the Readfile to gets its information
FolderToBackup = "FoldersTobackup"
LocationFolderToBackup = "./FoldersTobackup"
BackupFolder = "BackupFolder"
LocationBackupFolder = "./BackupFolder/"
MaxThreadsUsed = "4"
TimeSinceLastBackup = "20"
CompareFolderTime = "20"

TargetRecoveryfolder = "./RecoveryFolder"
RestoreZipFolder = "./RestoreZips"
